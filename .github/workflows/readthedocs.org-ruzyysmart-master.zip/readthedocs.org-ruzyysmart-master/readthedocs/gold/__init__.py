# -*- coding: utf-8 -*-

"""
A Django app for Gold membership.

Gold membership is Read the Docs' program for recurring, monthly donations.
"""
default_app_config = 'readthedocs.gold.apps.GoldAppConfig'
