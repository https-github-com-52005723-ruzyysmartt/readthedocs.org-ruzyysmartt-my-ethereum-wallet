from django.apps import AppConfig


class V3Config(AppConfig):
    name = 'v3'
