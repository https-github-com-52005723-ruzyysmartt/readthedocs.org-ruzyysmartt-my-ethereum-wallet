# -*- coding: utf-8 -*-
default_app_config = 'readthedocs.oauth.apps.OAuthConfig'
